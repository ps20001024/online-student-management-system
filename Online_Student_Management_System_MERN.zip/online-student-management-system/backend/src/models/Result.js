import mongoose from 'mongoose';
const resultSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
  course: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
  subject: { type: String, required: true, trim: true },
  examName: { type: String, default: 'Final Examination' },
  marksObtained: { type: Number, required: true, min: 0 },
  maximumMarks: { type: Number, required: true, min: 1 },
  examDate: { type: Date, default: Date.now }
}, { timestamps: true });
resultSchema.pre('validate', function(next) {
  if (this.marksObtained > this.maximumMarks) this.invalidate('marksObtained', 'Marks cannot exceed maximum marks');
  next();
});
export default mongoose.model('Result', resultSchema);
