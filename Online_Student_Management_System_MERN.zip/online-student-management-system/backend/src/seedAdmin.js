import 'dotenv/config';
import connectDB from './config/db.js';
import User from './models/User.js';
try {
  await connectDB();
  const name=process.env.ADMIN_NAME||'System Administrator';
  const email=(process.env.ADMIN_EMAIL||'admin@example.com').toLowerCase();
  const password=process.env.ADMIN_PASSWORD||'ChangeMe123!';
  if(password.length<8) throw new Error('ADMIN_PASSWORD must be at least 8 characters');
  const existing=await User.findOne({email});
  if(existing) console.log(`Admin already exists: ${email}`);
  else { await User.create({name,email,password,role:'admin'}); console.log(`Admin created: ${email}`); }
} catch(e){console.error(e.message);process.exitCode=1;} finally { const mongoose=(await import('mongoose')).default; await mongoose.disconnect(); }
